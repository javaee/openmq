/*
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS HEADER.
 *
 * Copyright 2000-2007 Sun Microsystems, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of either the GNU
 * General Public License Version 2 only ("GPL") or the Common Development
 * and Distribution License ("CDDL") (collectively, the "License").  You may
 * not use this file except in compliance with the License.  You can obtain
 * a copy of the License at https://glassfish.dev.java.net/public/CDDL+GPL.html
 * or mq/legal/LICENSE.txt.  See the License for the specific language
 * governing permissions and limitations under the License.
 *
 * When distributing the software, include this License Header Notice in each
 * file and include the License file at mq/legal/LICENSE.txt.  Sun designates
 * this particular file as subject to the "Classpath" exception as provided by
 * Sun in the GPL Version 2 section of the License file that accompanied this
 * code.  If applicable, add the following below the License Header, with the
 * fields enclosed by brackets [] replaced by your own identifying information:
 * "Portions Copyrighted [year] [name of copyright owner]"
 *
 * Contributor(s):
 *
 * If you wish your version of this file to be governed by only the CDDL or
 * only the GPL Version 2, indicate your decision by adding "[Contributor]
 * elects to include this software in this distribution under the [CDDL or GPL
 * Version 2] license."  If you don't indicate a single choice of license, a
 * recipient has the option to distribute your version of this file under
 * either the CDDL, the GPL Version 2 or  to extend the choice of license to
 * its licensees as provided above.  However, if you add GPL Version 2 code
 * and therefore, elected the GPL Version 2 license, then the option applies
 * only if the new code is made subject to such option by the copyright holder.
 */

using System;
using System.Net.Sockets;
using System.IO;
using System.Collections.Generic;

public class StompClient 
{
    static public void Main(string[] args) {
        bool runsender = true; 

        if (args.Length < 4) {
            Console.WriteLine(
                "Usage: StompClient: [s|r] <stomp-host> <stomp-port> <queue-name>");
            return;
        }
        TcpClient sock;

        if (args[0].Equals("r")) {
            runsender = false;
            Console.WriteLine("Running StompClient as receiver ..."); 
        } else {
            Console.WriteLine("Running StompClient as sender ..."); 
        }
       
        Console.WriteLine("Connecting to {0}:{1} ...", args[1], args[2]);
        try {
            sock = new TcpClient(args[1], int.Parse(args[2]));
        } catch (Exception ex) {
           Console.WriteLine(
           "Failed to connect to {0}:{1} - {2}", args[1], args[2], ex.ToString());
           return;
        }
        NetworkStream networkStream = sock.GetStream();
		StreamReader streamReader = new System.IO.StreamReader(networkStream);
        StreamWriter streamWriter = new System.IO.StreamWriter(networkStream);

        try {
            Console.WriteLine("CONNECT ...");
            streamWriter.WriteLine("CONNECT");
            streamWriter.WriteLine("login:guest");
            streamWriter.WriteLine("passcode:guest");
            streamWriter.WriteLine("");
            streamWriter.Write('\0');
            streamWriter.Flush();
            Console.WriteLine("Sent CONNECT");

            checkStatus(streamReader, "CONNECT");

            if (runsender) {
                Console.WriteLine("SEND a message ...");
                string msg = "Hello, This is a message from C# stomp client";
                streamWriter.WriteLine("SEND");
                streamWriter.WriteLine("destination:/queue/"+args[3]);
                streamWriter.WriteLine("receipt:message-1");
                streamWriter.WriteLine("");
                streamWriter.Write(msg);
                streamWriter.Write('\0');
                streamWriter.Flush();
                Console.WriteLine("Sent message:\n{0}", msg);
                checkStatus(streamReader, "SEND");
            } else {
                Console.WriteLine("SUBSCRIBE from queue {0}...", args[3]);
                streamWriter.WriteLine("SUBSCRIBE");
                streamWriter.WriteLine("destination:/queue/"+args[3]);
                streamWriter.WriteLine("");
                streamWriter.Write('\0');
                streamWriter.Flush();
                Console.WriteLine("Sent SUBSCRIBE");

                Console.WriteLine("Receiving message ...");
                List<string> reply = getReply(streamReader, "SUBSCRIBE");
                Console.WriteLine("Received Message:\n");
                foreach (string line in reply) {
                    Console.WriteLine(line);
                }
            }

            Console.WriteLine("DISCONNECT ...");
            streamWriter.WriteLine("DISCONNECT");
            streamWriter.WriteLine("");
            streamWriter.Write('\0');
            streamWriter.Flush();
        } catch (Exception ex) {
            Console.WriteLine("Exception occurred: {0}", ex.ToString());
        } finally {
            streamWriter.Close();
            streamReader.Close();
            networkStream.Close();
        }
    }

    static List<string> getReply(StreamReader reader, string protocol) {

        Console.WriteLine("Get {0} reply ...", protocol);
        List<string>  rep = new List<string>();
        rep.Add(reader.ReadLine());
        while (reader.Peek() != -1) {
            rep.Add(reader.ReadLine());
        }
        return rep;
    }

    static void checkStatus(StreamReader reader, string protocol) {

        List<string> reply = getReply(reader, protocol);
        foreach (string line in reply) {
            Console.WriteLine(line);
        }
        StringReader sr = new StringReader(reply[0]);
        string status = sr.ReadLine();
        if (status == null) {
            throw new IOException("No reply");
        }
        if (status.Equals("ERROR")) {
            throw new IOException(reply[0]);
        }
    }
}
